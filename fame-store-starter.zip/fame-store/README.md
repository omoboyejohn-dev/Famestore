# Fame Store

Starter frontend for the Fame Store gift-delivery marketplace.

## Included
- Responsive homepage
- Product/category browsing
- Search
- Sorting
- Shopping cart with localStorage
- Destination selector
- Mobile layout
- Gift categories and product cards

## Next production phase
1. User registration/login
2. Product database and admin dashboard
3. Product detail pages
4. Checkout and delivery address flow
5. Paystack integration with server-side verification/webhooks
6. Order tracking
7. Customer dashboard
8. Admin order management
9. Cloud image storage
10. Deployment and domain configuration

The current product images are external demo images and should be replaced with licensed/owned product images before launch.
