const products = [
  {id:1,name:"Pink Rose Bouquet",category:"Flowers",price:30000,image:"https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=700&q=80",badge:"Bestseller",rating:"4.8",reviews:120},
  {id:2,name:"Large Teddy Bear",category:"Teddy Bears",price:25000,old:28000,image:"https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=700&q=80",badge:"-10%",rating:"4.7",reviews:98},
  {id:3,name:"Chocolate Celebration Cake",category:"Cakes",price:20000,image:"https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=700&q=80",badge:"Bestseller",rating:"4.9",reviews:156},
  {id:4,name:"Pizza & Coke Combo",category:"Pizza & Drinks",price:15000,old:17500,image:"https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=700&q=80",badge:"-15%",rating:"4.6",reviews:75},
  {id:5,name:"Luxury Perfume",category:"Perfumes",price:45000,image:"https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&w=700&q=80",badge:"New",rating:"4.8",reviews:63},
  {id:6,name:"Premium Classic Watch",category:"Watches",price:85000,old:96000,image:"https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80",badge:"-12%",rating:"4.9",reviews:88},
  {id:7,name:"Smart Car Key Gift",category:"Car Keys",price:120000,image:"https://images.unsplash.com/photo-1551830820-330a71b99659?auto=format&fit=crop&w=700&q=80",badge:"Premium",rating:"4.7",reviews:34},
  {id:8,name:"Luxury Surprise Gift Box",category:"Gift Boxes",price:55000,image:"https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=700&q=80",badge:"Popular",rating:"4.9",reviews:61},
  {id:9,name:"Fresh Red Rose Bouquet",category:"Flowers",price:35000,image:"https://images.unsplash.com/photo-1494972308805-463bc619d34e?auto=format&fit=crop&w=700&q=80",badge:"New",rating:"4.8",reviews:41},
  {id:10,name:"Premium Gift Basket",category:"Gift Boxes",price:65000,image:"https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=700&q=80",badge:"Gift",rating:"4.8",reviews:52},
  {id:11,name:"Birthday Cake",category:"Cakes",price:28000,image:"https://images.unsplash.com/photo-1551024506-0bccd828d307?auto=format&fit=crop&w=700&q=80",badge:"Popular",rating:"4.7",reviews:72},
  {id:12,name:"Chocolate Gift Set",category:"Chocolates",price:18000,image:"https://images.unsplash.com/photo-1548907040-4d42cfcf4c6b?auto=format&fit=crop&w=700&q=80",badge:"Gift",rating:"4.8",reviews:39}
];

let cart = JSON.parse(localStorage.getItem("fameStoreCart") || "[]");
let selectedCategory = "all";

const money = n => "₦" + Number(n).toLocaleString("en-NG");

function renderProducts() {
  const grid = document.getElementById("productGrid");
  const search = document.getElementById("searchInput").value.trim().toLowerCase();
  const sort = document.getElementById("sortSelect").value;

  let list = products.filter(p => {
    const categoryMatch = selectedCategory === "all" || p.category === selectedCategory;
    const searchMatch = !search || `${p.name} ${p.category}`.toLowerCase().includes(search);
    return categoryMatch && searchMatch;
  });

  if (sort === "low") list.sort((a,b) => a.price-b.price);
  if (sort === "high") list.sort((a,b) => b.price-a.price);

  document.getElementById("resultText").textContent =
    list.length ? `${list.length} gift${list.length === 1 ? "" : "s"} available` : "No gifts found.";

  grid.innerHTML = list.map(p => `
    <article class="product-card">
      <img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy">
      <span class="badge">${p.badge}</span>
      <button class="wish" title="Save ${p.name}">♡</button>
      <div class="product-body">
        <span class="category-label">${p.category}</span>
        <h3>${p.name}</h3>
        <div class="rating">★ ${p.rating} (${p.reviews})</div>
        <div class="price">${money(p.price)} ${p.old ? `<span class="old-price">${money(p.old)}</span>` : ""}</div>
        <button class="add-btn" data-add="${p.id}">Add to Cart</button>
      </div>
    </article>
  `).join("") || `<div class="empty" style="grid-column:1/-1">Try another search or category.</div>`;

  grid.querySelectorAll("[data-add]").forEach(btn => {
    btn.addEventListener("click", () => addToCart(Number(btn.dataset.add)));
  });
}

function addToCart(id) {
  const item = products.find(p => p.id === id);
  if (!item) return;
  const existing = cart.find(x => x.id === id);
  if (existing) existing.qty++;
  else cart.push({...item, qty:1});
  saveCart();
  openCart();
}

function saveCart() {
  localStorage.setItem("fameStoreCart", JSON.stringify(cart));
  document.getElementById("cartCount").textContent = cart.reduce((s,x) => s+x.qty, 0);
  renderCart();
}

function renderCart() {
  const wrap = document.getElementById("cartItems");
  if (!cart.length) {
    wrap.innerHTML = `<p class="empty">Your cart is empty.</p>`;
  } else {
    wrap.innerHTML = cart.map(x => `
      <div class="cart-line">
        <img src="${x.image}" alt="${x.name}">
        <div><b>${x.name}</b><small>${x.qty} × ${money(x.price)}</small></div>
        <button class="remove" data-remove="${x.id}">Remove</button>
      </div>
    `).join("");
    wrap.querySelectorAll("[data-remove]").forEach(btn => {
      btn.onclick = () => {
        cart = cart.filter(x => x.id !== Number(btn.dataset.remove));
        saveCart();
      };
    });
  }
  document.getElementById("cartTotal").textContent = money(cart.reduce((s,x) => s + x.price*x.qty, 0));
}

function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("overlay").classList.add("show");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","false");
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("show");
  document.getElementById("cartDrawer").setAttribute("aria-hidden","true");
}

function chooseCategory(category) {
  selectedCategory = category;
  document.querySelectorAll(".nav-link").forEach(x => x.classList.toggle("active", x.dataset.category === category));
  document.getElementById("categorySelect").value = category;
  renderProducts();
  document.getElementById("products").scrollIntoView({behavior:"smooth"});
}

document.querySelectorAll("[data-category]").forEach(el => {
  el.addEventListener("click", () => chooseCategory(el.dataset.category));
});
document.getElementById("searchBtn").onclick = renderProducts;
document.getElementById("searchInput").addEventListener("input", renderProducts);
document.getElementById("categorySelect").addEventListener("change", e => chooseCategory(e.target.value));
document.getElementById("sortSelect").addEventListener("change", renderProducts);
document.getElementById("cartBtn").onclick = openCart;
document.getElementById("closeCart").onclick = closeCart;
document.getElementById("overlay").onclick = closeCart;
document.getElementById("checkoutBtn").onclick = () => {
  if (!cart.length) return alert("Your cart is empty.");
  alert("Checkout page will be connected to the real payment system in the next phase.");
};

document.getElementById("countrySelect").addEventListener("change", e => {
  const names = {NG:"Nigeria",GH:"Ghana",KE:"Kenya",US:"USA",GB:"UK",CA:"Canada"};
  document.getElementById("topCountry").textContent = names[e.target.value];
});

renderProducts();
saveCart();
